﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class inventory : UserControl
    {
        public inventory()
        {
            InitializeComponent();
        }

        private void Out_Click(object sender, EventArgs e)
        {

        }
    }
}
